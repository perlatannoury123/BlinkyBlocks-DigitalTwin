/*
 * user_code.c
 *
 *  Created on: oct. 21, 2022
 *      Author: Benoit Piranda
 */

#include <user_code.h>
#include <layer3_generic.h>
#include <microphone.h>
#include <speaker.h>
#include <light.h>
#include <abstraction.h>

void BBinit() {
}

void BBloop() {
}

uint8_t process_standard_packet(L3_packet *packet) {
	return 0;
}

void process_standard_ack(L3_packet *p) {
}

void process_standard_unack(L3_packet *p) {
}
