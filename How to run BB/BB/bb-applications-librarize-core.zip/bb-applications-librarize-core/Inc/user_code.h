/*
 * user_code.h
 *
 *  Created on: Jul 10, 2020
 *      Author: flassabe
 */

#ifndef _USER_CODE_H_
#define _USER_CODE_H_

#include <BB.h>

void BBinit();
void BBloop();

#endif // _USER_CODE_H_
