#include "bbpp.h"
#include <QDebug>
#include <exception>
#include <iostream>

using namespace std;

bbpp_task::bbpp_task(layer3 *l): bb_task(l) {
    _progress_subject.set_value(0.0);
    _completion_subject.set_value(false);
}

void bbpp_task::start() {
    _parser = make_unique<iHexParser>(_hex_file);
    _parser->parse();
    _parser->make_chunks(_chunks_size);
    uint32_t start_addr = _parser->getStartAddress();
    uint32_t prog_size = _parser->getProgramSize();
    _chunks_cnt = _parser->get_chunks_count();
    printf("Starting programming at address %x with program size %d in %d chunks\n", start_addr, prog_size, _chunks_cnt);
    vector<uint8_t> start_packet{BBPP_PACKET_TYPE_PROGRAM_START, static_cast<uint8_t>((start_addr>>24)&0xff), static_cast<uint8_t>((start_addr>>16)&0xff),
                                 static_cast<uint8_t>((start_addr>>8)&0xff), static_cast<uint8_t>(start_addr&0xff),
                                 static_cast<uint8_t>((prog_size>>24)&0xff), static_cast<uint8_t>((prog_size>>16)&0xff),
                                 static_cast<uint8_t>((prog_size>>8)&0xff), static_cast<uint8_t>(prog_size&0xff), static_cast<uint8_t>(_chunks_size-1),
                                 static_cast<uint8_t>((_chunks_cnt>>8)&0xff), static_cast<uint8_t>(_chunks_cnt&0xff)};
    get_layer3()->send_packet(start_packet, L3_BBPP, this, true);
}

void bbpp_task::process(const vector<uint8_t> &packet) {
    if (packet[0] == BBPP_PACKET_TYPE_CHUNK_REQUEST) {
        uint16_t chunk_index = packet[1]*256+packet[2];
        if (_parser == nullptr) return;
        try {
            qDebug() << "Request for chunk " << chunk_index;
            auto v = _parser->get_chunks().at(chunk_index);
            get_layer3()->send_packet(v, L3_BBPP, this, true);
            _progress_subject.set_value((double) (chunk_index+1) / (_chunks_cnt+1));
            _progress_subject.notify_observers();
        }  catch (out_of_range &e) {
            cout << "Chunk out of range" << endl;
        }
    } else if (packet[0] == BBPP_PACKET_TYPE_FINISHED) {
        qDebug() << "BB programming finished";
        _completion_subject.set_value(true);
        _completion_subject.notify_observers();
        end_task();
    }
}
