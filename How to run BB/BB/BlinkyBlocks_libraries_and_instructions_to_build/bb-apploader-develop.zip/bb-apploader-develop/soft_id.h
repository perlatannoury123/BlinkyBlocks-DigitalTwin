#ifndef SOFT_ID_H
#define SOFT_ID_H

#include <layer3.h>

class soft_id : public bb_task {
    uint32_t _first_id;

public:
    soft_id(layer3 *l, uint32_t first_id): bb_task(l), _first_id(first_id) {}
    virtual void start();
    virtual void process(const std::vector<uint8_t> &packet);
    virtual void notify_ack() {}
    virtual L3_packet_type get_type()const {return L3_SOFT_ID;}
};

#endif // SOFT_ID_H
