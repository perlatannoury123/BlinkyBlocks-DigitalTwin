#include "blinkyapploader.h"

/*!
 * \brief BlinkyApploader::BlinkyApploader default constructor does nothing
 */
BlinkyApploader::BlinkyApploader() {
}
