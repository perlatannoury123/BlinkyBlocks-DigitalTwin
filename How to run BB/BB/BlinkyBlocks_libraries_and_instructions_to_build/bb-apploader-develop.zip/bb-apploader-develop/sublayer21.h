#ifndef SUBLAYER21_H
#define SUBLAYER21_H

#include <cstdint>
#include <vector>
#include <QObject>
#include <memory>
#include <cstdarg>
#include <bf21codec.h>
#include <layer2.h>
#include <QtSerialPort>
#include <QString>
#include <QHostAddress>
#include <QTcpSocket>

enum _sublayer21_status {BETWEEN_FRAMES, IN_FRAME};
using sublayer21_status_t = enum _sublayer21_status;

enum _sublayer21_factory_type {PHY_SERIAL, PHY_SOCKET};
using sublayer21_factory_type_t = _sublayer21_factory_type;

class BLINKYAPPLOADERSHARED_EXPORT sublayer21: public QObject {
    Q_OBJECT

    std::unique_ptr<QIODevice> _interface;
    std::vector<uint8_t> _input_buffer;
    sublayer21_status_t _internal_state = BETWEEN_FRAMES;
    layer2 *_layer2_instance = nullptr;

public:
    sublayer21(std::unique_ptr<QIODevice> &&interface);
    ~sublayer21() {qDebug() << "sublayer21::dtor";}
    void set_layer2_instance(layer2 *l);
    bool has_layer2_instance()const {return _layer2_instance != nullptr;};
    void send_frame(std::vector<uint8_t> binary_frame);

    static std::unique_ptr<QIODevice> interface_factory(int iface_type, ...);

public slots:
    void data_received();
};

#endif // SUBLAYER21_H
