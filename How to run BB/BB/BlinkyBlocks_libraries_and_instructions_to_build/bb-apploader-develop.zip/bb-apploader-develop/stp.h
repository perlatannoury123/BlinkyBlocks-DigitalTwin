#ifndef STP_H
#define STP_H

#include <layer3.h>
#include <observer.hpp>

const uint8_t STP_COMMAND_CLEAR_TREE = 0x00;
const uint8_t STP_COMMAND_PARENT_REQUEST = 0x40;
const uint8_t STP_COMMAND_CHILD_ACCEPT = 0x80;
const uint8_t STP_COMMAND_CHILD_REJECT = 0xc0;

class BLINKYAPPLOADERSHARED_EXPORT stp_task: public bb_task {
    uint8_t _command;
    observed_object<uint32_t> _subject;
    observed_object<bool> _stp_result_subject;

public:
    stp_task(layer3 *l, uint8_t command=STP_COMMAND_PARENT_REQUEST): bb_task(l), _command(command) {}
    void start();
    void process(const std::vector<uint8_t> &packet);
    void notify_ack();
    L3_packet_type get_type()const {return L3_STP;}
    observed_object<uint32_t> *get_bb_count_subject() {return &_subject;}
    observed_object<bool> *get_stp_result_subject() {return &_stp_result_subject;}
};


#endif // STP_H
