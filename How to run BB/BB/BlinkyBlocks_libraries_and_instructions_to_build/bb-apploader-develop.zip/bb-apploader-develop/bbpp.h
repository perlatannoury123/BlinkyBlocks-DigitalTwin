#ifndef BBPP_H
#define BBPP_H

#include <layer3.h>
#include <observer.hpp>

typedef enum {
    BBPP_PACKET_TYPE_CHUNK = 0,
    BBPP_PACKET_TYPE_CHUNK_REQUEST = 1, // Request a chunk from the father
    BBPP_PACKET_TYPE_CHUNK_REQUEST_UNAVAILABLE = 2, // Response to chunk request: chunk not available
    BBPP_PACKET_TYPE_CHUNK_REQUEST_NOEXIST = 3, // Response to chunk request: chunk does not exist
    BBPP_PACKET_TYPE_PROGRAM_START = 4, // Start a programming process
    BBPP_PACKET_TYPE_START_OK = 5, // Child is ok to start programming
    BBPP_PACKET_TYPE_START_REJECT = 6, // Child cannot program
    BBPP_PACKET_TYPE_FINISHED = 7, // Sent to parent to notify that programming is finished
} BBPP_PacketType;

#define BBPP_DEFAULT_CHUNK_SIZE 128

class BLINKYAPPLOADERSHARED_EXPORT bbpp_task: public bb_task {
private:
    std::unique_ptr<iHexParser> _parser;
    uint16_t _chunks_cnt = 0;
    uint16_t _chunks_size = BBPP_DEFAULT_CHUNK_SIZE;
    std::string _hex_file;

    observed_object<bool> _completion_subject;
    observed_object<double> _progress_subject;

public:
    bbpp_task(layer3 *l=nullptr);
    void set_ihex_file(std::string &filename) {_hex_file = filename;}
    void set_chunks_size(uint16_t s) {_chunks_size = s;}
    virtual void start();
    virtual void process(const std::vector<uint8_t> &packet);
    virtual void notify_ack() {}
    virtual L3_packet_type get_type()const {return L3_BBPP;}
    observed_object<bool> *get_bbpp_completion_subject() {return &_completion_subject;}
    observed_object<double> *get_bbpp_progress_subject() {return &_progress_subject;}
};

#endif // BBPP_H
