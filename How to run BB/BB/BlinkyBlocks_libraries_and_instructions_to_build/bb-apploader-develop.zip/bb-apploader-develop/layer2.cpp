#include <layer2.h>
#include <layer3.h>
#include <csignal>
#include <unistd.h>
#include <bbpp.h>
#include <sublayer21.h>
#include <algorithm>

using namespace std;

const uint8_t MAX_TX_RETRIES = 3;

void display_binary_vector(const vector<uint8_t> &v) {
    for (const auto b: v) {
        printf(" %02X", b);
    }
    cout << endl;
}

/*!
 * \brief layer2::layer2 default constructor initializes the layer2 instance
 * with a pointer to the physical layer and initializes
 * the list of available sending slots
 * \param my_physical_layer a pointer to the physical layer (default nullptr)
 */
layer2::layer2(sublayer21 *_my_physical_layer, bool set_autoclose): QObject(), _autoclose(set_autoclose) {
    qDebug() << "layer2: ctor";
    if (_my_physical_layer)
        set_sublayer21_instance(_my_physical_layer);
    connect(&_ack_timeout_timer, &QTimer::timeout, this, &layer2::check_retransmissions);
    _ack_timeout_timer.start(50);
}

layer2::~layer2() {
    qDebug() << "layer2: dtor";
}

void layer2::set_sublayer21_instance(sublayer21 *l) {
    _sublayer21_instance = l;
    if (!l->has_layer2_instance())
        l->set_layer2_instance(this);
}

uint16_t layer2::compute_checksum(const std::vector<uint8_t> &frame) {
    uint16_t checksum = 0;
    for (uint8_t byte: frame) {
        checksum = (checksum >> 1) + ((checksum & 1) << 15);
        checksum += byte;
    }
    return checksum;
}

void layer2::process_frame(const std::vector<uint8_t> &frame) {
    uint16_t s = (frame[0] & 0x3) * 256 + frame[1];
    if (s != frame.size())
        return;

    vector<uint8_t> frame_content{frame.begin(), frame.end()-2}; // Copy frame without checksum
    uint16_t checksum = compute_checksum(frame_content);
    uint16_t source_checksum = frame[frame.size()-2] * 256 + frame[frame.size()-1];
    if (checksum != source_checksum)
        return;

    if ((frame[0] & 0x40) != 0) { // Ack is requested
        vector<uint8_t> ack_frame{frame.begin(), frame.begin()+4};
        ack_frame[0] &= 0x3f; // Change type to ack, no ack required
        ack_frame[1] = 8; // Ack frames always are 8-bytes long
        ack_frame.push_back(source_checksum / 256);
        ack_frame.push_back(source_checksum % 256);
        uint16_t ack_frame_checksum = compute_checksum(ack_frame);
        ack_frame.push_back(ack_frame_checksum / 256);
        ack_frame.push_back(ack_frame_checksum % 256);
        _sublayer21_instance->send_frame(ack_frame);
    }

    if ((frame[0] & 0x80) == 0) { // This is an ack, manage this
        if (frame.size() == 8) {
            checksum = frame[4] * 256 + frame[5];
            _layer_3->notify_ack_to_task(checksum);
            auto it = find_if(_pending_acks.begin(), _pending_acks.end(), [checksum](const tuple<qint64, int, vector<uint8_t>> &e) {
                const vector<uint8_t> &current_frame = get<2>(e);
                uint16_t current_checksum = current_frame[current_frame.size()-2]*256 + current_frame[current_frame.size()-1];
                return current_checksum==checksum;
            });
            if (it != _pending_acks.end())
                _pending_acks.erase(it);
        }
        return;
    }

    vector<uint8_t> packet{frame.begin()+4, frame.end()-2};
    _layer_3->process_packet((L3_packet_type) frame[2], packet);
}

uint16_t layer2::send_packet(const std::vector<uint8_t> &packet_bin, L3_packet_type pkt_type, bool with_ack) {
    vector<uint8_t> frame{};
    frame.push_back(0x80 + (with_ack ? 0x40 : 0) + ((packet_bin.size()+6) / 256));
    frame.push_back((packet_bin.size() + 6) % 256);
    frame.push_back(pkt_type);
    frame.push_back(0);
    frame.insert(frame.end(), packet_bin.begin(), packet_bin.end());
    uint16_t checksum = compute_checksum(frame);
    frame.push_back(checksum / 256);
    frame.push_back(checksum % 256);
    _sublayer21_instance->send_frame(frame);
    if (with_ack) {
        _pending_acks.push_back({QDateTime::currentMSecsSinceEpoch()+200, 2, frame});
    }
    return checksum;
}

void layer2::check_retransmissions() {
    qint64 current_time = QDateTime::currentMSecsSinceEpoch();
    vector<tuple<qint64, int, vector<uint8_t>>> remaining_frames;
    for (tuple<qint64, int, vector<uint8_t>> &frame: _pending_acks) {
        if (get<0>(frame) < current_time) {
            int remaining_retransmissions = get<1>(frame) - 1;
            _sublayer21_instance->send_frame(get<2>(frame));
            if (remaining_retransmissions > 0)
                remaining_frames.push_back({current_time+200, remaining_retransmissions, get<2>(frame)});
        } else
            remaining_frames.push_back(frame);
    }
    swap(_pending_acks, remaining_frames);
}
