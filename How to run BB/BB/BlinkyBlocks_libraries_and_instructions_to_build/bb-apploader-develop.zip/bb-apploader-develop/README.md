<div align="center">
    <img src="./bb-logo-text.png" alt="Blinky Blocks" />

<h1>bb-apploader</h1>

[programmable-matter.com](https://www.programmable-matter.com/technology/blinky-blocks)

</div>
The blinkyApploader library aims at loading ihex files to a set of Blinky Blocks through an entry point (serial connection) in the blocks set. This requires the blocks to be set in programming mode.

## Ubuntu libraries

```sh
apt-get install qtcreator
apt-get install libqt5serialport5-dev
apt-get install libqt5websockets5-dev
```

## Compiling the project

This project is developped under qtCreator. When using another tool, the .pro file must be converted to a Makefile with the qmake command. The dependencies for the project are the following (Fedora):
- qt5-qtbase-devel.x86_64
- qt5-qtserialport-devel.x86_64
- qt5-qtwebsockets.x86_64

## Using the project

You must implement a client application, which looks like this example:  
```cpp
#include <ihexparser.h>

int main(int argc, char *argv[]) {
  iHexParser p{"app.hex"};
  p.parse();
  p.write_binary("out.bin");
  return 0;
}
```

In this example, first, we create an ihex parser instance with a source file app.hex, then we parse the hex file, finally we output the resulting binary file to out.bin (this shall be the same file as the .bin output of the compilation instance which provided the .hex file).

## Known issues

For now, this library is a WIP, therefore, not all features are implemented (serial upload for instance)
