#ifndef LAYER_2_H
#define LAYER_2_H

#include <blinkyapploader_global.h>
#include <QObject>
#include <QTimer>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <memory>
#include <ihexparser.h>
#include <QDateTime>
#include <layer3.h>

class bb_task;

class wrong_frame_format_exception: public std::runtime_error {
public:
    wrong_frame_format_exception(): std::runtime_error("Binary frame too short < 6 bytes") {}
};

class slot_unavailable_exception: std::runtime_error {
public:
    slot_unavailable_exception(): std::runtime_error("No slot available") {}
//    ~slot_unavailable_exception();
};

class sublayer21;

/*!
 * \brief The layer2 class is in charge of managing layer 2 frames queues (incoming and outgoing)
 * and of sending those frames by a call to its lower physical layer.
 */
class BLINKYAPPLOADERSHARED_EXPORT layer2: public QObject {
    Q_OBJECT

    layer3 *_layer_3;                                       ///< Pointer to layer 3 to pass packets to
    sublayer21 *_sublayer21_instance;                       ///< Pointer to sublayer21 instance.

    std::vector<std::tuple<qint64, int, std::vector<uint8_t>>> _pending_acks;
    QTimer _ack_timeout_timer;

    bool _autoclose = false;

public:
    layer2(sublayer21 *_my_physical_layer = nullptr, bool set_autoclose=false);
    virtual ~layer2();
    layer2(const layer2 &other) = delete;
    layer2(layer2 &&other) = delete;
    layer2 &operator=(const layer2 &other) = delete;
    layer2 &operator =(layer2 &&other) = delete;

    void set_sublayer21_instance(sublayer21 *l);
    void set_layer3_instance(layer3 *l) {_layer_3 = l;}

    uint16_t compute_checksum(const std::vector<uint8_t> &frame);
    void process_frame(const std::vector<uint8_t> &frame);
    uint16_t send_packet(const std::vector<uint8_t> &packet_bin, L3_packet_type pkt_type, bool with_ack=false);

public slots:
    void check_retransmissions();
};

#endif // LAYER_2_H

