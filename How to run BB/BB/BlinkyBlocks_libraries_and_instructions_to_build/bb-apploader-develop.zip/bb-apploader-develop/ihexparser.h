#ifndef IHEXPARSER_H
#define IHEXPARSER_H

#include <string>
#include <set>
#include <vector>
#include <exception>
#include <iostream>
#include <fstream>
#include <blinkyapploader_global.h>
//#include <nikonetworkpacket.h>

/**
 * @brief HEX file format exception class
 */
class ihex_format_exception: public std::ios_base::failure {
public:
    /**
     * @brief Default exception constructor
     * @param message Exception message
     */
    ihex_format_exception(const std::string &message): std::ios_base::failure(message) {}
};

/*!
 * \brief The iHexParser class loads and converts iHex files to binary
 */
class BLINKYAPPLOADERSHARED_EXPORT iHexParser {
    std::string _source_file; ///< file path
    std::vector<unsigned char> _binary_content; ///< Binary parsed content
    uint32_t _start_address; ///< minimal start address of data
    std::set<unsigned long long> _missing_fragments; ///< List of missing fragments required by the remote BB
    std::vector<std::vector<uint8_t>> _chunks_map; ///< Splitted chunks of program

public:
    /**
     * @brief Forbidden default constructor
     */
    iHexParser() = delete;

    /*!
     * \brief Default constructor
     * \param filename the iHex source file name, as a char *
     */
    iHexParser(const char * filename): _source_file(std::string(filename)) {std::cout << "iHexParser: ctor" << std::endl;}

    /*!
     * \brief Default constructor
     * \param filename the iHex source file name, as a string
     */
    iHexParser(const std::string &filename): _source_file(filename) {}

    /**
     * @brief Empty destructor
     */
    ~iHexParser() {std::cout << "iHexParser: dtor" << std::endl;}

    void parse();

    void write_binary(const std::string &output_file);
    void write_binary(const char *output_file);

    /*!
     * \brief getStartAddress returns the start address of the Hex file (where it must be flashed into the target device memory)
     * \return the program start address value
     */
    uint32_t getStartAddress()const {return _start_address;}

    /*!
     * \brief getProgramSize returns the program binary size in bytes
     * \return the program size in bytes
     */
    uint32_t getProgramSize()const {return static_cast<uint32_t>(_binary_content.size());}
    std::vector<unsigned char> getFragment(unsigned long frag_addr);

    /*!
     * \brief getMissingFragments returns the missing fragment required by the programmed child
     * \return a const reference to the set of fragment defined by their address in the target device flash memory
     */
    const std::set<unsigned long long> &getMissingFragments()const {return _missing_fragments;}

    /*!
     * \brief getMissingFragments returns the missing fragment required by the programmed child
     * \return a reference to the set of fragment defined by their address in the target device flash memory
     */
    std::set<unsigned long long> &getMissingFragments() {return _missing_fragments;}

    void make_chunks(uint16_t chunk_size);

    /**
     * @brief Chunks vector count
     * @return Chunks count
     */
    uint16_t get_chunks_count()const {return _chunks_map.size();}

    /**
     * @brief Chunks vector getter
     * @return Chunks
     */
    std::vector<std::vector<uint8_t>> &get_chunks() {return _chunks_map;}

    /**
     * @brief Chunks vector getter
     * @return Chunks
     */
    const std::vector<std::vector<uint8_t>> &get_chunks()const {return _chunks_map;}

    std::vector<uint8_t> &&copy_chunk(uint16_t chunk_index);

    /**
     * @brief Clears chunk maps
     */
    void reset_chunks_map() {_chunks_map.clear();}
};

#endif // IHEXPARSER_H
