#include "soft_id.h"

const uint8_t SOFT_ID_PROTO_SET_SOFT_ID_REQUEST = 2;

void soft_id::start() {
    uint8_t id_bytes[4];
    id_bytes[0] = (_first_id>>24) & 0xff;
    id_bytes[1] = (_first_id>>16) & 0xff;
    id_bytes[2] = (_first_id>>8) & 0xff;
    id_bytes[3] = _first_id & 0xff;
    get_layer3()->send_packet({SOFT_ID_PROTO_SET_SOFT_ID_REQUEST, id_bytes[0], id_bytes[1], id_bytes[2], id_bytes[3]}, L3_SOFT_ID, this, true);
}

void soft_id::process(const std::vector<uint8_t> &packet) {
    uint32_t last_id = (packet[1]<<24) + (packet[2]<<16) + (packet[3]<<8) + packet[4];
    printf("BB ensemble assigned ID's %d to %d\n", _first_id, last_id);
    end_task();
}
