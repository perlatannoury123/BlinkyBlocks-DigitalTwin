#include "layer3.h"
#include <layer2.h>
#include <vector>
#include <cctype>
#include <QDebug>
#include <stp.h>
#include <iostream>

#include <debug_messages.h>
#include <recovery_jumper.h>

using namespace std;

layer3::layer3(layer2 *l2): _my_layer2(l2) {
    qDebug() << "layer3::ctor";

    auto debug_task = make_unique<debug_messages>(this);
    auto recov_task = make_unique<recovery_jumper>(this);
    auto std_task = make_unique<l3_standard_bg_task>(this);

    _debug_subject = debug_task->get_debug_subject();
    _recovery_subject = recov_task->get_hard_id_subject();
    _l3_standard_subject = std_task->get_l3_standard_subject();

    _background_tasks.push_back(std::move(debug_task));
    _background_tasks.push_back(std::move(recov_task));
    _background_tasks.push_back(std::move(std_task));
}

void layer3::process_packet(L3_packet_type pt, const std::vector<uint8_t> &packet) {
    if (!_tasks.empty() && _tasks.front()->get_type() == pt) {
        _tasks.front()->process(packet);
        if (_tasks.front()->has_ended()) { // If task has ended, remove it, remove its pending ack and start next one
            auto it = find_if(_pending_acks.begin(), _pending_acks.end(), [&](const pair<uint16_t, bb_task *> &e) {
                return e.second == _tasks.front().get();
            });
            if (it != _pending_acks.end())
                _pending_acks.erase(it);
            _tasks.erase(_tasks.begin());
            run_tasks();
        }
    } else {
        auto it = find_if(_background_tasks.begin(), _background_tasks.end(), [pt](const unique_ptr<bb_task> &e) {
            if (e->get_type() == pt)
                return true;
            return false;
        });
        if (it != _background_tasks.end()) {
            it->get()->process(packet);
        }
    }
    // Else: packet is dropped
}

void layer3::notify_ack_to_task(uint16_t acked_checksum) {
    try {
        _pending_acks.find(acked_checksum)->second->notify_ack();
        if (_tasks.front()->has_ended()) { // If task has ended, remove it and start next one
            _tasks.erase(_tasks.begin());
            run_tasks();
        }
    }  catch (std::out_of_range &e) {
        qDebug() << e.what() << Qt::endl;
    }
}

void layer3::send_packet(const std::vector<uint8_t> &packet, L3_packet_type pt, bb_task *attached_task, bool wants_ack) {
    uint16_t checksum = _my_layer2->send_packet(packet, pt, wants_ack);
    if (wants_ack) {
        _pending_acks.insert({checksum, attached_task});
    }
}

void layer3::run_tasks() {
    if (!_tasks.empty()) {
        qDebug() << "Processing tasks" << Qt::endl;
        _tasks.front()->start();
    } else {
        _all_task_processed_subject.set_value(true);
        _all_task_processed_subject.notify_observers();
        qDebug() << "All tasks have been processed";
    }
}

void l3_standard_bg_task::process(const std::vector<uint8_t> &packet) {
    _l3_standard_subject.set_value(packet);
    _l3_standard_subject.notify_observers();
}
