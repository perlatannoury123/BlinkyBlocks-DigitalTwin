#ifndef DEVICE_COMMAND_TASK_H
#define DEVICE_COMMAND_TASK_H

#include <layer3.h>
#include <cstdarg>
#include <observer.hpp>

typedef enum {
    DEVICE_COMMAND_SET_AUTOSTART=1,
    DEVICE_COMMAND_SET_AUTOSTART_DELAY=2,
    DEVICE_COMMAND_SET_COLOR=32,
    DEVICE_COMMAND_START_APP=33,
    DEVICE_COMMAND_REBOOT=34,
    DEVICE_COMMAND_GET_BB_VERSION=37,
    DEVICE_COMMAND_ERASE_CONFIGURATION=125,
    DEVICE_COMMAND_GET_CONFIGURATION=126,
    DEVICE_COMMAND_COMMIT_CHANGES=128,
} device_command_t;

class BLINKYAPPLOADERSHARED_EXPORT device_command_task : public bb_task {
    bool _waiting_for_ack;

public:
    static std::unique_ptr<device_command_task> device_command_factory(layer3 *l, int t, ...);
    virtual void start() = 0;
    virtual void process(const std::vector<uint8_t> &packet) = 0;
    virtual void notify_ack() = 0;
    L3_packet_type get_type()const {return L3_DEVICE;}
    device_command_task(layer3 *l, bool wfa=false);
};

class BLINKYAPPLOADERSHARED_EXPORT device_command_flash_write: public device_command_task {
    uint8_t _var_id;
    uint32_t _var_value;

public:
    void start();
    void process(const std::vector<uint8_t> &packet) {}
    void notify_ack() {end_task();}
    device_command_flash_write(layer3 *l, uint8_t var_id, uint32_t var_value);
};

class BLINKYAPPLOADERSHARED_EXPORT device_command_set_color: public device_command_task {
    uint8_t _red;
    uint8_t _green;
    uint8_t _blue;

public:
    void start();
    void process(const std::vector<uint8_t> &packet) {}
    void notify_ack() {end_task();}
    device_command_set_color(layer3 *l, uint8_t r, uint8_t g, uint8_t b);
};

class BLINKYAPPLOADERSHARED_EXPORT device_command_reboot: public device_command_task {
public:
    void start();
    void process(const std::vector<uint8_t> &packet) {}
    void notify_ack() {end_task();}
    device_command_reboot(layer3 *l): device_command_task(l, true) {}
};

class BLINKYAPPLOADERSHARED_EXPORT device_command_start_app: public device_command_task {
    uint32_t _application_address;

public:
    void start();
    void process(const std::vector<uint8_t> &packet) {}
    void notify_ack() {end_task();}
    device_command_start_app(layer3 *l, uint32_t address);
};

class BLINKYAPPLOADERSHARED_EXPORT device_command_get_bb_version: public device_command_task {
    observed_object<std::map<std::string, std::tuple<uint8_t, uint8_t, uint8_t>>> _bb_list;
    uint32_t _bb_count;
public:
    ~device_command_get_bb_version() {}
    void start();
    void process(const std::vector<uint8_t> &packet);
    void notify_ack() {}
    device_command_get_bb_version(layer3 *l): device_command_task(l, false), _bb_count(0) {}
    observed_object<std::map<std::string, std::tuple<uint8_t, uint8_t, uint8_t>>> *get_bb_list() {return &_bb_list;}
};

class BLINKYAPPLOADERSHARED_EXPORT device_command_erase_config: public device_command_task {
public:
    void start();
    void process(const std::vector<uint8_t> &packet) {}
    void notify_ack() {end_task();}
    device_command_erase_config(layer3 *l): device_command_task(l, true) {}
};

class BLINKYAPPLOADERSHARED_EXPORT bb_configuration {
    uint32_t _config_offset = 0;
    bool _application_autostart = false;
    uint32_t _autostart_delay = 1;
    uint32_t _soft_id = 0;
    uint32_t _application_address = 0x8008000;
    uint32_t _free_variables[11];

public:
    bb_configuration() {}
    ~bb_configuration() {}

    void set_config_offset(uint32_t offset) {_config_offset = offset;}
    uint32_t get_config_offset()const {return _config_offset;}

    void set_application_autostart(bool is_enabled) {_application_autostart = is_enabled;}
    bool get_application_autostart()const {return _application_autostart;}

    void set_autostart_delay(uint32_t delay) {_autostart_delay = delay;}
    uint32_t get_autostart_delay()const {return _autostart_delay;}

    void set_soft_id(uint32_t id) {_soft_id = id;}
    uint32_t get_soft_id()const {return _soft_id;}

    void set_application_address(uint32_t address) {_application_address = address;}
    uint32_t get_application_address()const {return _application_address;}

    void set_free_variable(uint8_t index, uint32_t value) {if (index < 11) _free_variables[index] = value;}
    uint32_t get_free_variable(uint8_t index)const {if (index < 11) return _free_variables[index]; else return 0;}
};

class BLINKYAPPLOADERSHARED_EXPORT device_command_get_config: public device_command_task {
    observed_object<bb_configuration> _the_configuration;

public:
    void start();
    void process(const std::vector<uint8_t> &packet);
    virtual void notify_ack() {}
    device_command_get_config(layer3 *l): device_command_task(l, false) {}
    observed_object<bb_configuration> *get_config_subject() {return &_the_configuration;}
};

class BLINKYAPPLOADERSHARED_EXPORT bb_count_singleton {
    uint32_t _bb_count;
    static bb_count_singleton *instance;
    bb_count_singleton(): _bb_count(0) {};
    ~bb_count_singleton() {}
public:
    static bb_count_singleton *get_instance() {return instance;}
    void set_count(uint32_t c) {_bb_count = c;}
    uint32_t get_count()const {return _bb_count;}
    void destroy() {delete instance;}
};

#endif // DEVICE_COMMAND_TASK_H
