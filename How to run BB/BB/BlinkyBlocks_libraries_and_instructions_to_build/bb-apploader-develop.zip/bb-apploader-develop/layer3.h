#ifndef LAYER3_H
#define LAYER3_H

#include <blinkyapploader_global.h>
#include <ihexparser.h>
#include <observer.hpp>
#include <memory>
#include <string>
#include <map>
#include <QDebug>

class layer2;

/*!
 * \brief enum L3_packet_type defines the type of packet encapsulated in a frame
 * When an ACK frame is sent, you must use the same packet type so it is properly processed
 */
typedef enum {
    L3_NONE, ///< Default initialized value
    L3_NORMAL, ///< Standard source/destination packet
    L3_STP, ///< Spanning tree packet
    L3_BBPP, ///< Blinky block Batch Programming Protocol
    L3_DEVICE, ///< Device commands
    L3_SOFT_ID, ///< Soft ID configuration
    L3_DEBUG_MESSAGE, ///< Debug message
    L3_RECOVERY, ///< Message testing recovery of bootloader
    L3_IMPL_COUNT, ///< Number of L3 implementations
} L3_packet_type;

class layer3;

class BLINKYAPPLOADERSHARED_EXPORT bb_task {
private:
    layer3 *_layer3_instance;
    bool _has_ended;

public:
    bb_task(layer3 *l): _layer3_instance(l), _has_ended(false) {}
    virtual ~bb_task() {}
    virtual void start() = 0;
    virtual void process(const std::vector<uint8_t> &packet) = 0;
    virtual void notify_ack() = 0;
    virtual L3_packet_type get_type()const = 0;
    bool has_ended()const {return _has_ended;}

    void end_task() {_has_ended = true;}
    layer3 *get_layer3()const {return _layer3_instance;}
};

class l3_standard_bg_task: public bb_task {
    observed_object<std::vector<uint8_t>> _l3_standard_subject;
public:
    l3_standard_bg_task(layer3 *l): bb_task(l) {}
    ~l3_standard_bg_task() {}
    virtual void start() {}
    virtual void process(const std::vector<uint8_t> &packet);
    virtual void notify_ack() {}
    virtual L3_packet_type get_type()const {return L3_NORMAL;}
    observed_object<std::vector<uint8_t>> *get_l3_standard_subject() {return &_l3_standard_subject;}
};

class layer2;

class BLINKYAPPLOADERSHARED_EXPORT layer3 {
protected:
    layer2 *_my_layer2;
    std::vector<std::unique_ptr<bb_task>> _background_tasks;
    std::vector<std::unique_ptr<bb_task>> _tasks;
    std::map<uint16_t, bb_task *> _pending_acks;
    observed_object<bool> _all_task_processed_subject;

    observed_object<std::vector<uint8_t>> *_debug_subject;
    observed_object<std::vector<uint8_t>> *_recovery_subject;
    observed_object<std::vector<uint8_t>> *_l3_standard_subject;

public:
    layer3(layer2 *l2=nullptr);
    ~layer3() {qDebug() << "layer3::dtor";}
    void process_packet(L3_packet_type pt, const std::vector<uint8_t> &packet);
    void notify_ack_to_task(uint16_t acked_checksum);
    void send_packet(const std::vector<uint8_t> &packet, L3_packet_type pt, bb_task *attached_task, bool wants_ack=false);

    void add_task(std::unique_ptr<bb_task> &&t) {_tasks.push_back(std::move(t));}
    void run_tasks();
    bool has_remaining_tasks()const {return !_tasks.empty();}
    observed_object<bool> *get_layer3_tasks_complete_subject() {return &_all_task_processed_subject;}
    observed_object<std::vector<uint8_t>> *get_debug_subject() {return _debug_subject;}
    observed_object<std::vector<uint8_t>> *get_recovery_subject() {return _recovery_subject;}
    observed_object<std::vector<uint8_t>> *get_l3_standard_subject() {return _l3_standard_subject;}
};

#endif // LAYER3_H
