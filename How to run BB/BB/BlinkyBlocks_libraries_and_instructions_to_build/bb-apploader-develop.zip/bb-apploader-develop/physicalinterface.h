#ifndef PHYSICALINTERFACE_H
#define PHYSICALINTERFACE_H

#include <QObject>

/**
 * @brief Integer representation used to distinguish PhysicalInterface types
 */
typedef enum {
    INTERFACE_UNKNOWN = 0, ///< We don't know this interface yet
    INTERFACE_WIFI_STA, ///< Wi-Fi station interface
    INTERFACE_WIFI_AP, ///< Wi-Fi Access Point interface
    INTERFACE_SERIAL, ///< Serial wire interface
} InterfaceType;

/**
 * @brief Description for each interface in #InterfaceType enum
 */
const char* const InterfaceTypeDesc[] = {
    "Unknown",
    "Wifi Station",
    "WiFi AP",
    "Serial"
};

/**
 * @brief Class presenting physical interfaces
 */
class PhysicalInterface
{
    Q_GADGET
    Q_PROPERTY(QString name READ getName) ///<Human readable name for display uses only
    Q_PROPERTY(QString id READ getId) ///< Unique ID to differentiate interfaces
    Q_PROPERTY(InterfaceType type READ getType) ///< Interface type used to choose the corresponding PhysicalLayer
    Q_PROPERTY(QString address READ getAddress) ///< Connection address for PhysicalLayer
public:
    /**
     * @brief Default empty interface
     */
    explicit PhysicalInterface() = delete;

    /**
     * @brief PhysicalInterface Constructor
     * @param id Unique ID to differentiate interfaces
     * @param name Human readable name for display uses only
     * @param type Interface type used to choose the corresponding PhysicalLayer
     * @param address Connection address for PhysicalLayer
     */
    explicit PhysicalInterface(QString id, QString name, InterfaceType type, QString address) :
        m_id(id),
        m_name(name),
        m_type(type),
        m_address(address) {};

    /**
     * @brief Empty destructor
     */
    virtual ~PhysicalInterface() {};

    QString m_id; ///< ID of the interface, must be unique
    QString m_name; ///< Human-readable name for it
    InterfaceType m_type; ///< Interface type
    QString m_address; ///< Address to connect to: can be a com name port, an ip address...

    QString getName() { return m_name; } ///< Human readable name getter
    QString getId() { return m_id; } ///< Unique ID getter
    InterfaceType getType() { return m_type; } ///< Interface type number getter
    QString getAddress() { return m_address; } ///< Connection address getter
};

// Q_DECLARE_METATYPE(PhysicalInterface);

#endif // PHYSICALINTERFACE_H
