#ifndef DEBUG_MESSAGES_H
#define DEBUG_MESSAGES_H

#include <layer3.h>
#include <observer.hpp>

const uint8_t DEBUG_MESSAGE_TO_ROOT = 1;

class BLINKYAPPLOADERSHARED_EXPORT debug_messages : public bb_task {
    observed_object<std::vector<uint8_t>> _debug_subject;

public:
    debug_messages(layer3 *l): bb_task(l) {}
    virtual void start() {}
    virtual void process(const std::vector<uint8_t> &packet);
    virtual void notify_ack() {}
    virtual L3_packet_type get_type()const {return L3_DEBUG_MESSAGE;}
    observed_object<std::vector<uint8_t>> *get_debug_subject() {return &_debug_subject;}
};

#endif // DEBUG_MESSAGES_H
