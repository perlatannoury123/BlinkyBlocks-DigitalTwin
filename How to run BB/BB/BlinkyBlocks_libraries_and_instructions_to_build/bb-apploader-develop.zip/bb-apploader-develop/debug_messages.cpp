#include "debug_messages.h"
#include <iostream>

using namespace std;

void debug_messages::process(const std::vector<uint8_t> &packet) {
    if (packet[0] == DEBUG_MESSAGE_TO_ROOT) {
        _debug_subject.set_value(vector<uint8_t>{packet.begin()+1, packet.end()});
        _debug_subject.notify_observers();
    }
}
