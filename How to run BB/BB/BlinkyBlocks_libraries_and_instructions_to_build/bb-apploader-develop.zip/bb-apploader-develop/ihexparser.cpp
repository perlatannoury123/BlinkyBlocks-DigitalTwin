#include "ihexparser.h"

#include <array>
#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;

/*!
 * \brief parse parses the _source_file (whose value is assigned by the constructor)
 * Throws an exception if an error occurs.
 */
void iHexParser::parse() {
    uint16_t min_address = 0xffff;
    bool reached_eof = false;
    string value_table = "0123456789ABCDEF";
    ifstream input_file{_source_file, ios_base::in};
    if (!input_file.is_open())
        throw ios_base::failure{"File " + _source_file + " does not exist"};
    for (array<char, 128> a; input_file.getline(&a[0], 128);) {
        if (a[0] != ':')
            throw ihex_format_exception{"HEX format erroneous"};
        // Step 1: extract line size, address, and record type
        int length, addr, rectype;
        char content[100];
        sscanf(&a[1], "%2x%4x%2x%s", &length, &addr, &rectype, content);
        if (length > 64)
            throw ihex_format_exception("HEX data line too long");
        switch (rectype) {
        case 0: // Data packet
            if (addr < min_address)
                min_address = addr;
            for (int i=0; i<length; ++i) {
                _binary_content.push_back(16 * value_table.find(content[2*i]) + value_table.find(content[2*i+1]));
            }
            // TODO: use the checksum to check data
            break;
        case 1: // Enf of file
            reached_eof = true;
            break;
        case 2:
            break;
        case 3:
            break;
        case 4: // Extended start address
            char rest[100];
            sscanf(content, "%4x%s", &_start_address, rest);
            _start_address = _start_address << 16;
            break;
        case 5:
            break;
        }
        if (reached_eof)
            break;
    }
    _start_address += min_address;
}

/*!
 * \brief write_binary writes the binary content into the output_file
 * \param output_file the path to the output binary file
 */
void iHexParser::write_binary(const string &output_file) {
    write_binary(output_file.c_str());
}

/*!
 * \brief write_binary writes the binary content into the output_file
 * \param output_file the path to the output binary file
 */
void iHexParser::write_binary(const char *output_file) {
    ofstream outputf{output_file, ios_base::binary};
    outputf.write((const char *)&_binary_content[0], _binary_content.size());
}

/*!
 * \brief iHexParser::getFragment gets a fragment from the fragments list based on its address
 * \param frag_addr the address of the fragment in the target device flash memory
 * \return the fragment content as a vector of uint8_t
 */
std::vector<unsigned char> iHexParser::getFragment(unsigned long frag_addr) {
    unsigned long offset = frag_addr - _start_address;
    int remaining_size = _binary_content.size() - offset;
    int frag_size = min(16, remaining_size);
    vector<unsigned char> frag{_binary_content.begin()+offset, _binary_content.begin()+offset+frag_size};
    return frag;
}

/**
 * @brief Creates binary chunks with binary content
 * @param chunk_size the chunk size wanted
 */
void iHexParser::make_chunks(uint16_t chunk_size) {
    _chunks_map.clear();
    uint16_t current_chunk_index = 0;
    while (_binary_content.size() > current_chunk_index*chunk_size) {
        uint32_t pos = current_chunk_index*chunk_size;
        uint32_t end_pos = min(_binary_content.size(), static_cast<size_t>(pos+chunk_size));
        _chunks_map.push_back({initializer_list<uint8_t>{0, static_cast<uint8_t>(current_chunk_index/256),
                                                         static_cast<uint8_t>(current_chunk_index%256), static_cast<uint8_t>(end_pos-pos-1)}});
        _chunks_map[current_chunk_index].insert(_chunks_map[current_chunk_index].end(), _binary_content.begin()+pos, _binary_content.begin()+end_pos);
        ++current_chunk_index;
    }
    // Check
    for (size_t i=0; i<_binary_content.size(); ++i) {
        if (_binary_content[i] != _chunks_map[i/chunk_size][i%chunk_size+4]) {
            cout << "Error when building chunks map" << endl;
            break;
        }
        if (i == _binary_content.size()-1)
            cout << "Chunks map ok" << endl;
    }
}

/**
 * @brief Moves chunk at index
 * @param chunk_index chuck index wanted
 * @return moved chunk
 */
std::vector<uint8_t> &&iHexParser::copy_chunk(uint16_t chunk_index) {
    vector<uint8_t> v{_chunks_map.at(chunk_index)};
    return move(v);
}

