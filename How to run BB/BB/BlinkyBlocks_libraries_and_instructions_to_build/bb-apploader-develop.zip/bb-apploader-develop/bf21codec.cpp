#include "bf21codec.h"

using namespace std;

/*!
 * \brief BF21Codec::BF21Codec default constructor, does nothing
 */
BF21Codec::BF21Codec() {
}

/*!
 * \brief BF21Codec::encode encodes the L2 frame as a vector by escaping ~ and . character using @ as special character
 * \param data the frame to encode
 * \return the encoded frame
 */
std::vector<uint8_t> BF21Codec::encode(const std::vector<uint8_t> &data) {
    vector<uint8_t> encoded;
    for (const uint8_t &c: data) {
        switch (c) {
        case '@':
            encoded.push_back('@');
            encoded.push_back('A');
            break;
        case '~':
            encoded.push_back('@');
            encoded.push_back('B');
            break;
		case '.':
			encoded.push_back('@');
			encoded.push_back('C');
            break;
        case 'H':
            encoded.push_back('@');
            encoded.push_back('D');
            break;
        default:
            encoded.push_back(c);
            break;
        }
    }
    return encoded;
}

/**
* Decode string escaping ~ and . character using @ as special caracter
**/
/*!
 * \brief BF21Codec::decode decodes a received frame by substitution of:
 * @A -> @
 * @B -> ~
 * @C -> .
 * \param data the encoded received frame
 * \return the decoded frame without its delimiters
 */
std::vector<uint8_t> BF21Codec::decode(const std::vector<uint8_t> &data) {
    vector<uint8_t> decoded;

    unsigned int i = 0;
    while (i < data.size()) {
        if (data[i] == '@') {
            if (i+1 > data.size()-1) throw BF21_format_exception("Special character has no following"); // if there is an @ and no further character
            ++i;
            switch (data[i]) {
            case 'A':
                decoded.push_back('@');
                break;
            case 'B':
                decoded.push_back('~');
                break;
            case 'C':
                decoded.push_back('.');
                break;
            case 'D':
                decoded.push_back('H');
                break;
            default:
                throw BF21_format_exception("Wrong following character"); // If there is an @ followed by another character than A, B or C
            }
        } else {
            decoded.push_back(data[i]);
        }
        ++i;
    }
    return decoded;
}
