#ifndef BF21CODEC_H
#define BF21CODEC_H

#include <blinkyapploader_global.h>

#include <vector>
#include <string>
#include <iostream>

/*!
 * \brief The BF21_format_exception class manages BigFoot21 exceptions (malformed frames, etc.)
 */
class BF21_format_exception: public std::ios_base::failure {
public:
    /*!
     * \brief BF21_format_exception constructor only calls parent class constructor
     * \param message the message to expose in cas there is an exception
     */
    BF21_format_exception(const std::string &message): std::ios_base::failure(message) {}
};

/*!
 * \brief The BF21Codec class provides two static functions for encoding/decoding BF21 frames
 */
class BLINKYAPPLOADERSHARED_EXPORT BF21Codec {
public:
    BF21Codec();
    static std::vector<uint8_t> encode(const std::vector<uint8_t> &data);
    static std::vector<uint8_t> decode(const std::vector<uint8_t>&data);
};

#endif // BF21CODEC_H
