#ifndef OBSERVER_HPP
#define OBSERVER_HPP

#include <vector>
#include <algorithm>

template <typename T>
class observed_object;

template <typename T>
class observer {
protected:
    observed_object<T> *_object;

public:
    observer(observed_object<T> *oo);
    virtual ~observer();
    virtual void detach() {_object = nullptr;}
    virtual void update() = 0;
};

template <typename T>
class observed_object {
    T _value;
    std::vector<observer<T> *> _observers;

public:
    ~observed_object();
    void set_value(const T &v) {_value = v;}
    const T &get_value()const {return _value;}
    T &get_value() {return _value;}
    void add_observer(observer<T> *o) {_observers.push_back(o);}
    void remove_observer(observer<T> *o);
    void notify_observers();
};

template<typename T>
observer<T>::observer(observed_object<T> *oo): _object(oo) {
    if (oo)
        oo->add_observer(this);
}

template<typename T>
observer<T>::~observer() {
    if (_object) {
        _object->remove_observer(this);
    }
}

template<typename T>
observed_object<T>::~observed_object() {
    for (auto &obs: _observers)
        obs->detach();
}

template<typename T>
void observed_object<T>::remove_observer(observer<T> *o) {
    auto it = std::find(_observers.begin(), _observers.end(), o);
    if (it != _observers.end()) {
        _observers.erase(it);
    }
}

template<typename T>
void observed_object<T>::notify_observers() {
    for (observer<T> *o: _observers) {
        if (o)
            o->update();
    }
}

#endif // OBSERVER_HPP
