#include "stp.h"
#include <QDebug>
#include <layer3.h>

using namespace std;

void stp_task::start() {
    get_layer3()->send_packet(vector<uint8_t>{_command}, L3_STP, this, true);
}

void stp_task::process(const std::vector<uint8_t> &packet) {
    if (packet[0] == STP_COMMAND_CHILD_ACCEPT) {
        uint32_t children_count = (packet[1] << 24) + (packet[2]<<16) + (packet[3]<<8) + packet[4];
//        cout << "Blinky block accepted me with BB count: " << children_count << endl;
        _stp_result_subject.set_value(true);
        _stp_result_subject.notify_observers();
        _subject.set_value(children_count);
        _subject.notify_observers();
    } else if (packet[0] == STP_COMMAND_CHILD_REJECT) {
        _stp_result_subject.set_value(false);
        _stp_result_subject.notify_observers();
//        qDebug() << "Blinky blocks refused being my child" << Qt::endl;
    }
    end_task();
}

void stp_task::notify_ack() {
    if (_command == STP_COMMAND_CLEAR_TREE)
        end_task();
}

