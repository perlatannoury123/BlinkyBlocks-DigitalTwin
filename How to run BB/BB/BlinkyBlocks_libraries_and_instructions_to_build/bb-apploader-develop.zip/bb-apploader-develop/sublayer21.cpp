#include <sublayer21.h>

sublayer21::sublayer21(std::unique_ptr<QIODevice> &&interface): _interface(std::move(interface)) {
    qDebug() << "sublayer21::ctor";
    connect(_interface.get(), &QIODevice::readyRead, this, &sublayer21::data_received);
}

void sublayer21::send_frame(std::vector<uint8_t> binary_frame) {
    // TODO: check interface status before
    auto encoded_bf21_frame = BF21Codec::encode(binary_frame);
    std::vector<char> bytes_stream{'~'};
    bytes_stream.insert(bytes_stream.end(), encoded_bf21_frame.begin(), encoded_bf21_frame.end());
    bytes_stream.push_back('.');
    _interface->write(bytes_stream.data(), bytes_stream.size());
}

/*!
 * \brief sublayer21::interface_factory
 * \param iface_type either PHY_SERIAL for serial interface, or PHY_SOCKET for socket connection
 * Then, variadic arguments are:
 * For PHY_SERIAL:
 *  - Port name (e.g. "/dev/ttyUSB0")
 *  - Baud rate (e.g. 115200)
 * For PHY_SOCKET:
 *  - blinky-bridge IP address (as a char *)
 *  - blinky-bridge listening port (as an int)
 * \return
 */
std::unique_ptr<QIODevice> sublayer21::interface_factory(int iface_type, ...) {
    va_list args;
    va_start (args, iface_type);
    if (iface_type == PHY_SERIAL) {
        auto interface = std::make_unique<QSerialPort>();
        interface->setPortName(QString{va_arg(args, char*)});
        interface->setBaudRate(va_arg(args, int));
        interface->setDataBits(QSerialPort::Data8);
        interface->setStopBits(QSerialPort::StopBits::OneStop);
        interface->setParity(QSerialPort::Parity::NoParity);
        interface->open(QIODevice::ReadWrite);
        va_end(args);
        return interface;
    } else if (iface_type == PHY_SOCKET) {
        QHostAddress remote_addr{va_arg(args, char*)};
        quint16 port = va_arg(args, int);
        auto interface = std::make_unique<QTcpSocket>();
        interface->connectToHost(remote_addr, port);
        // Connect ?
        interface->waitForConnected(-1);
        va_end(args);
        return interface;
    }
    va_end(args);
    return std::unique_ptr<QIODevice>(nullptr);
}

void sublayer21::set_layer2_instance(layer2 *l) {
    _layer2_instance = l;
    l->set_sublayer21_instance(this);
}

void sublayer21::data_received() {
    QByteArray data = _interface->readAll();

    for (uint8_t c: data) {
        if (_internal_state == BETWEEN_FRAMES) {
            if (c == '~') {
                _internal_state = IN_FRAME;
            }
        } else if (_internal_state == IN_FRAME) {
            if (c == 'H') {
                continue;
            } else if (c == '.') {
                try {
                    auto frame = BF21Codec::decode(_input_buffer);
                    _input_buffer.clear();
                    _internal_state = BETWEEN_FRAMES;
                    _layer2_instance->process_frame(frame);
                }  catch (BF21_format_exception &e) {
                    qDebug("BF21 Codec decoding error: %s\n", e.what());
                }
            } else if (c == '~') {
                _input_buffer.clear(); // Flush incomplete frame
            } else {
                _input_buffer.push_back(c);
            }
        }
    }
}
