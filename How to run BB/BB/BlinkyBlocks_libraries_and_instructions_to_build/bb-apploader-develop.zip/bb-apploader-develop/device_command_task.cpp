#include "device_command_task.h"
#include <memory>

using namespace std;

std::unique_ptr<device_command_task> device_command_task::device_command_factory(layer3 *l, int t,...) {
    uint32_t param;
    va_list args;
    va_start (args, t);
    switch (static_cast<device_command_t>(t)) {
    case DEVICE_COMMAND_START_APP:
        param = va_arg(args, unsigned int);
        va_end(args);
        return make_unique<device_command_start_app>(l, param);
        break;
    case DEVICE_COMMAND_REBOOT:
        va_end(args);
        return make_unique<device_command_reboot>(l);
        break;
    case DEVICE_COMMAND_COMMIT_CHANGES:
        va_end(args);
        return make_unique<device_command_flash_write>(l, DEVICE_COMMAND_COMMIT_CHANGES, 1);
        break;
    case DEVICE_COMMAND_ERASE_CONFIGURATION:
        va_end(args);
        return make_unique<device_command_erase_config>(l);
        break;
    case DEVICE_COMMAND_GET_BB_VERSION:
        va_end(args);
        return make_unique<device_command_get_bb_version>(l);
        break;
    case DEVICE_COMMAND_GET_CONFIGURATION:
        va_end(args);
        return make_unique<device_command_get_config>(l);
        break;
    case DEVICE_COMMAND_SET_AUTOSTART:
        param = va_arg(args, unsigned int);
        va_end(args);
        return make_unique<device_command_flash_write>(l, 1, param);
        break;
    case DEVICE_COMMAND_SET_AUTOSTART_DELAY:
        param = va_arg(args, unsigned int);
        param = param << 24;
        va_end(args);
        return make_unique<device_command_flash_write>(l, 2, param);
        break;
    case DEVICE_COMMAND_SET_COLOR:
        uint8_t red = va_arg(args, int);
        uint8_t green = va_arg(args, int);
        uint8_t blue = va_arg(args, int);
        va_end(args);
        return make_unique<device_command_set_color>(l, red, green, blue);
        break;
    }

    va_end(args);
}

device_command_task::device_command_task(layer3 *l, bool wfa): bb_task(l), _waiting_for_ack(wfa) {
}

void device_command_flash_write::start() {
    uint8_t val[4];
    val[0] = (_var_value >> 24) & 0xff;
    val[1] = (_var_value >> 16) & 0xff;
    val[2] = (_var_value >> 8) & 0xff;
    val[3] = _var_value & 0xff;
    get_layer3()->send_packet({_var_id, val[0], val[1], val[2], val[3]}, L3_DEVICE, this, true);
}

device_command_flash_write::device_command_flash_write(layer3 *l, uint8_t var_id, uint32_t var_value):
    device_command_task(l, true), _var_id(var_id), _var_value(var_value) {
}

void device_command_set_color::start() {
    get_layer3()->send_packet({DEVICE_COMMAND_SET_COLOR, _red, _green, _blue}, L3_DEVICE, this, true);
}

device_command_set_color::device_command_set_color(layer3 *l, uint8_t r, uint8_t g, uint8_t b):
    device_command_task(l, true), _red(r), _green(g), _blue(b){
}

void device_command_get_config::start() {
    get_layer3()->send_packet({DEVICE_COMMAND_GET_CONFIGURATION}, L3_DEVICE, this, true);
}

uint32_t le_from_network(const uint8_t bytes[]) {
    uint32_t le_value = (bytes[0]<<24) + (bytes[1]<<16) + (bytes[2]<<8) + bytes[3];
    return le_value;
}

void device_command_get_config::process(const std::vector<uint8_t> &packet) {
    bb_configuration config;
    config.set_config_offset(le_from_network(&packet[1]));
    config.set_application_autostart(packet[8] == 0 ? false : true);
    config.set_autostart_delay(packet[12]);
    config.set_soft_id(le_from_network(&packet[13]));
    config.set_application_address(le_from_network(&packet[17]));
    for (int i=5; i<16; ++i)
        config.set_free_variable(i-5, le_from_network(&packet[4*i+1]));
    _the_configuration.set_value(config);
    _the_configuration.notify_observers();
    end_task();
}

void device_command_reboot::start() {
    get_layer3()->send_packet({DEVICE_COMMAND_REBOOT}, L3_DEVICE, this, true);
}

void device_command_start_app::start() {
    uint8_t addr_bytes[4];
    addr_bytes[0] = (_application_address>>24) & 0xff;
    addr_bytes[1] = (_application_address>>16) & 0xff;
    addr_bytes[2] = (_application_address>>8) & 0xff;
    addr_bytes[3] = _application_address & 0xff;
    get_layer3()->send_packet({DEVICE_COMMAND_START_APP, addr_bytes[0], addr_bytes[1], addr_bytes[2], addr_bytes[3]}, L3_DEVICE, this, true);
}

device_command_start_app::device_command_start_app(layer3 *l, uint32_t address): device_command_task(l, true) {
    _application_address = address;
}

void device_command_erase_config::start() {
    get_layer3()->send_packet({DEVICE_COMMAND_ERASE_CONFIGURATION}, L3_DEVICE, this, true);
}

void device_command_get_bb_version::start() {
     _bb_count = bb_count_singleton::get_instance()->get_count();
    get_layer3()->send_packet({DEVICE_COMMAND_GET_BB_VERSION}, L3_DEVICE, this, true);
}

typedef struct {
    uint8_t command;
    uint8_t version_major;
    uint8_t version_minor;
    uint8_t bb_revision;
    uint8_t hardware_id[12];
} id_version_t;

void make_bb_id(char result[], const uint8_t id[]) {
    result[0] = '\0';
    for (uint8_t i=0; i<12; ++i) {
        char current[4];
        sprintf(current, "%02x%s", id[i], (i==11) ? "" : ":");
        strcat(result, current);
    }
}

void device_command_get_bb_version::process(const std::vector<uint8_t> &packet) {
    const id_version_t *p = reinterpret_cast<const id_version_t *>(packet.data());
    char bb_id[36];
    make_bb_id(bb_id, p->hardware_id);
    _bb_list.get_value().insert({string{bb_id}, {p->version_major, p->version_minor, p->bb_revision}});
    --_bb_count;
    if (!_bb_count) {
        _bb_list.notify_observers();
        end_task();
    }
}

bb_count_singleton *bb_count_singleton::instance = new bb_count_singleton();
