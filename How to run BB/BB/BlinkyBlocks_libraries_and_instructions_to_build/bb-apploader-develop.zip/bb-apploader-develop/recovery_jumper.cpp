#include "recovery_jumper.h"

void recovery_jumper::process(const std::vector<uint8_t> &packet) {
    _hard_id_subject.set_value(packet);
    _hard_id_subject.notify_observers();
}
