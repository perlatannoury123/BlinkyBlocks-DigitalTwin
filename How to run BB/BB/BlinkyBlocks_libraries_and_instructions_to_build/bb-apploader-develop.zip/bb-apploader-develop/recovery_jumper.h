#ifndef RECOVERY_JUMPER_H
#define RECOVERY_JUMPER_H

#include <layer3.h>
#include <observer.hpp>

class recovery_jumper : public bb_task {
    observed_object<std::vector<uint8_t>> _hard_id_subject;

public:
    recovery_jumper(layer3 *l): bb_task(l) {}
    virtual void start() {}
    virtual void process(const std::vector<uint8_t> &packet);
    virtual void notify_ack() {}
    virtual L3_packet_type get_type()const {return L3_RECOVERY;};
    observed_object<std::vector<uint8_t>> *get_hard_id_subject() {return &_hard_id_subject;}
};

#endif // RECOVERY_JUMPER_H
