#ifndef _ERROR_HANDLER_H_
#define _ERROR_HANDLER_H_

void Error_Handler();

#endif // _ERROR_HANDLER_H_
