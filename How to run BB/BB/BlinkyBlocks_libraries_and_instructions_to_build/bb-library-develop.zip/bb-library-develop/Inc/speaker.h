#ifndef _SPEAKER_H_
#define _SPEAKER_H_

void setHWBUZZER(unsigned short usFreq, unsigned short usDuration);

#endif // _SPEAKER_H_
