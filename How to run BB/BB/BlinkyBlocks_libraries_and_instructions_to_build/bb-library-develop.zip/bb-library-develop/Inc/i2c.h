#ifndef _I2C_H_
#define _I2C_H_

void MX_I2C1_Init(void);

#endif //_I2C_H_
