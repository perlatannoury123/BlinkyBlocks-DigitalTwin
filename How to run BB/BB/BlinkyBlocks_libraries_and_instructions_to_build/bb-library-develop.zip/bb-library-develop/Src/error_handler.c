/*
 * error_handler.c
 *
 *  Created on: 12 juil. 2021
 *      Author: flassabe
 */

#include <error_handler.h>

void Error_Handler() {}

