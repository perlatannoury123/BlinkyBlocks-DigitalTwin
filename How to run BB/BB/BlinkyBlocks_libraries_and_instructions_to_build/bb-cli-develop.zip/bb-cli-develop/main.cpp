#include <iostream>
#include <exception>
#include <stdexcept>
#include <array>
#include <tuple>
#include <algorithm>
#include <csignal>
#include <getopt.h>
#include <unistd.h>
#include <memory>
#include <map>
#include <cstdio>

#include <bf21codec.h>
#include <sublayer21.h>
#include <layer2.h>
#include <layer3.h>
#include <stp.h>
#include <device_command_task.h>
#include <soft_id.h>
#include <bbpp.h>
#include <observer.hpp>

#include <QCoreApplication>

using namespace std;

enum RequestType {NONE, GET_ID, SET_LED};

map<string, uint8_t> variables_ids = {
    {"Application autostart", 1},
    {"Application autostart delay", 2},
    {"Soft ID", 3},
    {"Commit configuration", 128}
};

void display_help(char *prog_name) {
    size_t padding = (string("Usage: ") + string(prog_name)).size();
    cout << "Usage: " << prog_name << endl;
    cout << string(padding, ' ') << "-h display this message" << endl;
    cout << string(padding, ' ') << "-s <SERIAL> sets serial interface name" << endl;
    cout << string(padding, ' ') << "-c <R,G,B> sets connected blinky to color R,G,B" << endl;
    cout << string(padding, ' ') << "-t applies command to blocks ensemble (builds a spanning tree)" << endl;
    cout << string(padding, ' ') << "-e erase configuration" << endl;
    cout << string(padding, ' ') << "-p <HEX file> starts sending HEX file to connected blinky ensemble" << endl;
    cout << string(padding, ' ') << "-j 0xAAAAAAAA jumps to application address AAAAAAAA" << endl;
    cout << string(padding, ' ') << "-k <ID min> sets blinky blocks software ID, starting with <ID min>" << endl;
    cout << string(padding, ' ') << "-g requests blinky block to send its configuration" << endl;
    cout << string(padding, ' ') << "-v displays current apploader version date" << endl;
    cout << string(padding, ' ') << "-V displays blinky blocks version and hardware IDs" << endl;
    cout << string(padding, ' ') << "-r reboots BB ensemble" << endl;
    cout << string(padding, ' ') << "-a <1|0> enables (1) or disables (0) the full parallel programming feature" << endl;
    cout << string(padding, ' ') << "-o clears spanning tree" << endl;
    cout << string(padding, ' ') << "-q enables application autoclose" << endl;
    cout << string(padding, ' ') << "-H <hex string with even symbols count> sends a L3_NORMAL packet with content equal to hex string" << endl;
    cout << string(padding, ' ') << "-w <VAR ID,VAR VALUE> sets blinky block variable <VAR ID> to value <VAR VALUE>" << endl;
    for (const auto &element: variables_ids) {
        cout << string(padding+3, ' ') << element.first << " -> " << to_string(element.second) << endl;
    }
}

class Color {
    int _r;
    int _g;
    int _b;
public:
    Color(int r=0, int g=0, int b=0): _r(min(100, r)), _g(min(100, g)), _b(min(100, b)) {}
    Color(const Color &other) = default;
    Color(Color &&other) = default;
    Color &operator=(const Color &other) = default;
    Color &operator=(Color &&other) = default;
    ~Color() {}
    void setRed(int r) {_r = min(100, r);}
    void setGreen(int g) {_g = min(100, g);}
    void setBlue(int b) {_b = min(100, b);}
    int getRed()const {return _r;}
    int getGreen()const {return _g;}
    int getBlue()const {return _b;}
};

auto getVarIdAndValue(const char *var_str) {
    size_t comma;
    string s{var_str};
    comma = s.find(",");
    if (comma != string::npos) {
        uint8_t var_id = stoi(s.substr(0, comma));
        uint32_t var_value = stoull(s.substr(comma+1));
        printf("Var value: %x\n", var_value);
        return make_tuple(var_id, var_value);
    }
    return make_tuple<uint8_t, uint32_t>(0, 0);
}

Color getColor(const char *color_str) {
    int r=0, g=0, b=0;
    sscanf(color_str, "%d,%d,%d", &r, &g, &b);
    return Color{r, g, b};
}

class bb_list_observer: public observer<map<string, tuple<uint8_t, uint8_t, uint8_t>>> {
public:
    bb_list_observer(observed_object<map<string, tuple<uint8_t, uint8_t, uint8_t>>> *oo):
        observer<map<string, tuple<uint8_t, uint8_t, uint8_t>>>(oo) {}
    ~bb_list_observer() {}
    virtual void update();
};

class config_observer: public observer<bb_configuration> {
public:
    config_observer(observed_object<bb_configuration> *oo): observer<bb_configuration>(oo) {}
    ~config_observer() {}
    virtual void update();
};

class bbpp_progress_observer: public observer<double> {
    bool first_display=true;
public:
    bbpp_progress_observer(observed_object<double> *oo): observer<double>(oo) {}
    ~bbpp_progress_observer() {}
    virtual void update();
};

class bbpp_completion_observer: public observer<bool> {
public:
    bbpp_completion_observer(observed_object<bool> *oo): observer<bool>(oo) {}
    ~bbpp_completion_observer() {}
    virtual void update();
};

class stp_completion_observer: public observer<bool> {
public:
    stp_completion_observer(observed_object<bool> *oo): observer<bool>(oo) {}
    ~stp_completion_observer() {}
    virtual void update();
};

class bb_count_observer: public observer<uint32_t> {
public:
    bb_count_observer(observed_object<uint32_t> *oo): observer<uint32_t>(oo) {}
    ~bb_count_observer() {}
    virtual void update();
};

class task_queue_observer: public observer<bool> {
private:
    bool _must_autoclose=false;
    QTimer _timer_before_exit;

public:
    task_queue_observer(observed_object<bool> *oo): observer<bool>(oo) {}
    ~task_queue_observer() {}
    virtual void update();
    void set_autoclose() {_must_autoclose = true;}
};

class vector_uint8_t_observer: public observer<vector<uint8_t>> {
private:
    bool _output_text=false;
public:
    vector_uint8_t_observer(observed_object<vector<uint8_t>> *oo): observer<vector<uint8_t>>(oo) {}
    ~vector_uint8_t_observer() {}
    void set_output_text(bool is_text) {_output_text=is_text;}
    virtual void update();
};

class l3_standard_send: public bb_task {
    vector<uint8_t> _data;

public:
    l3_standard_send(layer3 *l): bb_task(l) {}
    ~l3_standard_send() {}
    virtual void start();
    virtual void process(const std::vector<uint8_t> &packet) {}
    virtual void notify_ack() {end_task();}
    virtual L3_packet_type get_type()const {return L3_NORMAL;}
    void set_content(const vector<uint8_t> c) {_data = c;}
};

int main(int argc, char *argv[]) {
    string serial_port = "/dev/ttyUSB0";
    string hex_file = "";
    QCoreApplication a(argc, argv);
    unique_ptr<iHexParser> ihex_parser;
    Color c;
    uint32_t jump_address;
    bool help_required = false;

    layer2 layer2_instance{};
    layer3 layer3_instance{&layer2_instance};
    layer2_instance.set_layer3_instance(&layer3_instance);

    task_queue_observer tasks_obs{layer3_instance.get_layer3_tasks_complete_subject()};
    vector_uint8_t_observer debug_obs{layer3_instance.get_debug_subject()};
    vector_uint8_t_observer recov_obs{layer3_instance.get_recovery_subject()};
    vector_uint8_t_observer std_obs{layer3_instance.get_l3_standard_subject()};
    debug_obs.set_output_text(true);

    unique_ptr<config_observer> config_obs;
    unique_ptr<bbpp_completion_observer> bbpp_cplt_obs;
    unique_ptr<bbpp_progress_observer> bbpp_progress_obs;
    unique_ptr<stp_completion_observer> stp_cplt_obs;
    unique_ptr<bb_count_observer> bb_count_obs;
    unique_ptr<bb_list_observer> bb_list_obs;

    int opt;
    while ((opt = getopt(argc, argv, "s:p:tj:c:hw:k:gervVoqH:")) != -1) {
        if (opt == 'r') {
            layer3_instance.add_task(device_command_task::device_command_factory(&layer3_instance, DEVICE_COMMAND_REBOOT));
        } else if (opt == 's') {
            serial_port = optarg;
        } else if (opt == 'p') {
            auto bbpp = make_unique<bbpp_task>(&layer3_instance);
            string hex_file{optarg};
            bbpp->set_ihex_file(hex_file);
            bbpp_cplt_obs = make_unique<bbpp_completion_observer>(bbpp->get_bbpp_completion_subject());
            bbpp_progress_obs = make_unique<bbpp_progress_observer>(bbpp->get_bbpp_progress_subject());
            layer3_instance.add_task(std::move(bbpp));
        } else if (opt == 'v') {
            printf("%s version from %s %s\n", argv[0], __DATE__, __TIME__);
            help_required = true;
        } else if (opt == 't') {
            auto stp_tsk = make_unique<stp_task>(&layer3_instance);
            stp_cplt_obs = make_unique<stp_completion_observer>(stp_tsk->get_stp_result_subject());
            bb_count_obs = make_unique<bb_count_observer>(stp_tsk->get_bb_count_subject());
            layer3_instance.add_task(std::move(stp_tsk));
        } else if (opt == 'c') {
            c = getColor(optarg);
            layer3_instance.add_task(device_command_task::device_command_factory(&layer3_instance,
                                                                                 DEVICE_COMMAND_SET_COLOR, c.getRed(), c.getGreen(), c.getBlue()));
        } else if (opt == 'j') {
            sscanf(optarg, "0x%x", &jump_address);
            layer3_instance.add_task(device_command_task::device_command_factory(&layer3_instance, DEVICE_COMMAND_START_APP, jump_address));
        } else if (opt == 'h') {
            display_help(argv[0]);
            help_required = true;
        } else if (opt == 'w') {
            uint8_t var_ID;
            uint32_t var_value;
            tie(var_ID, var_value) = getVarIdAndValue(optarg);

            if (var_ID == 128) { // Commit configuration changes
                layer3_instance.add_task(device_command_task::device_command_factory(&layer3_instance, DEVICE_COMMAND_COMMIT_CHANGES));
            } else if (var_ID == 1) { // Change configuration for application autostart & autostart delay
                layer3_instance.add_task(device_command_task::device_command_factory(&layer3_instance, DEVICE_COMMAND_SET_AUTOSTART, 0x01000000));
            } else if (var_ID == 2) { // Change configuration for application autostart & autostart delay
                layer3_instance.add_task(device_command_task::device_command_factory(&layer3_instance, DEVICE_COMMAND_SET_AUTOSTART_DELAY, var_value));
            } else if (var_ID > 2 && var_ID < 32){
                layer3_instance.add_task(device_command_task::device_command_factory(&layer3_instance, var_ID, var_value));
            }
        } else if (opt == 'k') {
            uint32_t base_id = atoi(optarg);
            layer3_instance.add_task(make_unique<soft_id>(&layer3_instance, base_id));
        } else if (opt == 'g') {
            auto cfg_task = make_unique<device_command_get_config>(&layer3_instance);
            config_obs = make_unique<config_observer>(cfg_task->get_config_subject());
            layer3_instance.add_task(std::move(cfg_task));
        } else if (opt == 'V') {
            auto version_task = make_unique<device_command_get_bb_version>(&layer3_instance);
            bb_list_obs = make_unique<bb_list_observer>(version_task->get_bb_list());
            layer3_instance.add_task(std::move(version_task));
        } else if (opt == 'H') {
            if (strlen(optarg) % 2 == 0) {
                size_t i = 0;
                if (strncmp(optarg, "0x", 2) == 0) {
                    i = 2;
                }
                vector<uint8_t> content;
                for (; i<strlen(optarg); i+=2) {
                    unsigned int v;
                    sscanf((char*) (optarg+i), "%2x", &v);
                    content.push_back((uint8_t) v);
                }
                auto standard_send = make_unique<l3_standard_send>(&layer3_instance);
                standard_send->set_content(content);
                layer3_instance.add_task(std::move(standard_send));
            }
        } else if (opt == 'e') {
            layer3_instance.add_task(device_command_task::device_command_factory(&layer3_instance, DEVICE_COMMAND_ERASE_CONFIGURATION));
        } else if (opt == 'o') {
            layer3_instance.add_task(make_unique<stp_task>(&layer3_instance, STP_COMMAND_CLEAR_TREE));
        } else if (opt == 'q') {
            tasks_obs.set_autoclose();
        }
	}

    if (help_required)
        return 0;

    sublayer21 sublayer21_instance{sublayer21::interface_factory(PHY_SERIAL, serial_port.c_str(), 115200)};
    layer2_instance.set_sublayer21_instance(&sublayer21_instance);
    layer3_instance.run_tasks();

    signal(SIGINT, [](int sig){ extern QCoreApplication *pa; sig=sig; pa->quit(); });
    QObject::connect(&a, &QCoreApplication::aboutToQuit, [=] () {
        cout << "Quitting" << endl;
    });
    bb_count_singleton::get_instance()->destroy();
    return a.exec();
}

void config_observer::update() {
    if (_object) {
        const bb_configuration &conf = _object->get_value();
        cout << "Configuration: " << endl;
        cout << "Configuration offset: " << conf.get_config_offset() << endl;
        cout << "Application autostart " << (conf.get_application_autostart() ? "enabled" : "disabled") << endl;
        cout << "Autostart delay: " << conf.get_autostart_delay() << endl;
        cout << "Soft ID: " << conf.get_soft_id() << endl;
        uint32_t app_addr = conf.get_application_address();
        printf("Application address: 0x%02X%02X%02X%02X\n", ((app_addr>>24) & 0xff), ((app_addr>>16) & 0xff), ((app_addr>>8) & 0xff), (app_addr & 0xff));
    }
}

void bbpp_progress_observer::update() {
    if (first_display)
        first_display = false;
    else
        printf("\r\r\r\r\r\r");
    double percentage = _object->get_value() * 100.0;
    printf("%03.2f%%", percentage);
    fflush(stdout);
}

void bbpp_completion_observer::update() {
    printf("\nProgramming finished!\n");
}

void bb_count_observer::update() {
    if (_object) {
        cout << _object->get_value() << endl;
        bb_count_singleton::get_instance()->set_count(_object->get_value());
    }
}

void stp_completion_observer::update() {
    if (_object) {
        if (_object->get_value()) {
            cout << "Blinky block accepted me with BB count: "; // endl in call to bb count
        } else {
            cout << "Blinky blocks refused being my child" << endl;
        }
    }
}

void task_queue_observer::update() {
    // We don't check observed value since it is only triggered by the completion of all tasks
    if (_must_autoclose) {
        cout << "All tasks are processed" << endl << "Exiting..." << endl;
        QObject::connect(&_timer_before_exit, &QTimer::timeout, [=](){
            raise(SIGINT);
        });
        _timer_before_exit.setSingleShot(true);
        _timer_before_exit.start(500);
    }
}

void vector_uint8_t_observer::update() {
    if (!_object) return ;
    vector<uint8_t> v{_object->get_value()};
    if (_output_text) {
        for_each(v.begin(), v.end(), [](const uint8_t &e){
            /*if (isprint(e))
                printf("%c", e);
            else*/
                printf("%02X ", e);
        });
    } else {
        for (const uint8_t &e: v)
            printf("%02X ", (e & 0xff));
    }
    printf("\n");
}

void l3_standard_send::start() {
    get_layer3()->send_packet(_data, L3_NORMAL, this, true);
}

void bb_list_observer::update() {
    if (_object) {
        for (const auto &entry: _object->get_value()) {
            printf("%s,%d.%d.%d\n", entry.first.c_str(), get<0>(entry.second), get<1>(entry.second), get<2>(entry.second));
            //cout << entry.first << "," << static_cast<uint8_t>(get<0>(entry.second)) << "."
            //     << static_cast<uint8_t>(get<1>(entry.second)) << "."
            //     << static_cast<uint8_t>(get<2>(entry.second)) << endl;
        }
    }
}
