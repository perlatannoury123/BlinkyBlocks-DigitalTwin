/*
 * microphone.h
 *
 *  Created on: 11 juil. 2020
 *      Author: flassabe
 */

#ifndef MICROPHONE_H_
#define MICROPHONE_H_

void MX_ADC_Init();
void ADC1_COMP_IRQHandler();

#endif /* MICROPHONE_H_ */
