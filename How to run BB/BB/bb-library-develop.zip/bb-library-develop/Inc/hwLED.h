#ifndef _HWLED_H_
#define _HWLED_H_

#include "stm32f0xx_hal.h"

#define LED_ADDR	0xCC
#define MAX_CURRENT	39 // =20mA


#endif // _HWLED_H_
